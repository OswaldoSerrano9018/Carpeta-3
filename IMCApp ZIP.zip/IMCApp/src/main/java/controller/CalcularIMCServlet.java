package controller;



import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Usuario;
import service.IMCService;
import service.UsuarioService;


@WebServlet("/calcularIMC")
public class CalcularIMCServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private IMCService _imcService;
    private UsuarioService usuarioService;
    
    private final UsuarioService _usuarioService;

    public CalcularIMCServlet(UsuarioService usuarioService, IMCService imcService) {
        this._usuarioService = usuarioService;
        this._imcService = imcService;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("nombreUsuario") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String nombreUsuario = (String) session.getAttribute("nombreUsuario");
        double peso = Double.parseDouble(request.getParameter("peso"));

        if (peso <= 0) {
            response.sendRedirect("error.jsp");
            return;
        }

        Usuario usuario = usuarioService.obtenerUsuario(nombreUsuario);
        double imc = this._imcService.calcularIMC(peso, usuario.getEstatura());
        this._imcService.guardarIMC(usuario, imc);

        request.setAttribute("imc", imc);
        request.getRequestDispatcher("historial").forward(request, response);
    }
}
