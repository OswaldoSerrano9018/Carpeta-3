package controller;



import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Usuario;
import service.IMCService;

import service.UsuarioService;

@WebServlet("/historial")
public class HistorialServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private final UsuarioService _usuarioService;
    private final IMCService _IMCService;

    public HistorialServlet(UsuarioService usuarioService, IMCService imcService) {
        this._usuarioService = usuarioService;
        this._IMCService = imcService;
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("nombreUsuario") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String nombreUsuario = (String) session.getAttribute("nombreUsuario");
        Usuario usuario = this._usuarioService.obtenerUsuario(nombreUsuario);

        request.setAttribute("historialIMC", this._IMCService.obtenerHistorialIMC(usuario));
        request.getRequestDispatcher("historial.jsp").forward(request, response);
    }
}