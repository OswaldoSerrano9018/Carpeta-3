package controller;


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import service.IMCService;
import model.Usuario;
import service.UsuarioService;
import com.google.gson.*;

@WebServlet("/api/historial")
public class RESTService extends HttpServlet {
	
    private static final long serialVersionUID = 1L;

    private Gson gson = new Gson();
    
    
    private final UsuarioService _usuarioService;
    private final IMCService _imcService;

    public RESTService(UsuarioService usuarioService, IMCService imcService) {
        this._usuarioService = usuarioService;
        this._imcService = imcService;
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nombreUsuario = request.getParameter("nombreUsuario");

        if (nombreUsuario == null) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }

        Usuario usuario = this._usuarioService.obtenerUsuario(nombreUsuario);
        if (usuario == null) {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        String historialIMCJson = gson.toJson(this._imcService.obtenerHistorialIMC(usuario));
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        out.print(historialIMCJson);
        out.flush();
    }
}