package controller;

import model.Usuario;
import service.UsuarioService;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/registro")
public class RegistroServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final UsuarioService _usuarioService;

    public RegistroServlet(UsuarioService usuarioService) {
        this._usuarioService = usuarioService;
    }
   // private UsuarioService usuarioService = new UsuarioService();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nombreCompleto = request.getParameter("nombreCompleto");
        String nombreUsuario = request.getParameter("nombreUsuario");
        int edad = Integer.parseInt(request.getParameter("edad"));
        String sexo = request.getParameter("sexo");
        double estatura = Double.parseDouble(request.getParameter("estatura"));
        String contrasena = request.getParameter("contrasena");
        
        if (estatura < 1.0 || estatura > 2.5 || edad < 15) {
            response.sendRedirect("error.jsp");
        } else {
            Usuario usuario = new Usuario(nombreCompleto, nombreUsuario, edad, sexo, estatura, contrasena);
            this._usuarioService.registrarUsuario(usuario);
            response.sendRedirect("login.jsp");
        }
    }
}
