package dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.IMC;
import utils.DatabaseConnection;

import model.Usuario;

public class IMCDAO {

    public void insertarIMC(Usuario usuario, IMC imc) {
        String sql = "INSERT INTO IMC (idUsuario, valorIMC, fecha) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, usuario.getIdUsuario());
            stmt.setDouble(2, imc.getValorIMC());
            stmt.setDate(3, new java.sql.Date(imc.getFecha().getTime()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<IMC> obtenerHistorialIMC(Usuario usuario) {
        List<IMC> historialIMC = new ArrayList<>();
        String sql = "SELECT * FROM IMC WHERE idUsuario = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                IMC imc = new IMC(rs.getDouble("valorIMC"), rs.getDate("fecha"));
                historialIMC.add(imc);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return historialIMC;
    }
}