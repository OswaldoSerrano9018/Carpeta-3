package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Usuario;
import utils.DatabaseConnection;

public class UsuarioDAO {

    public void insertarUsuario(Usuario usuario) {
        String sql = "INSERT INTO Usuarios (nombreCompleto, nombreUsuario, edad, sexo, estatura, contrasena, fechaRegistro) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, usuario.getNombreCompleto());
            stmt.setString(2, usuario.getNombreUsuario());
            stmt.setInt(3, usuario.getEdad());
            stmt.setString(4, usuario.getSexo());
            stmt.setDouble(5, usuario.getEstatura());
            stmt.setString(6, usuario.getContrasena());
            stmt.setDate(7, new java.sql.Date(System.currentTimeMillis()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Usuario obtenerUsuario(String nombreUsuario) {
        String sql = "SELECT * FROM Usuarios WHERE nombreUsuario = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombreUsuario);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Usuario(
                        rs.getString("nombreCompleto"),
                        rs.getString("nombreUsuario"),
                        rs.getInt("edad"),
                        rs.getString("sexo"),
                        rs.getDouble("estatura"),
                        rs.getString("contrasena")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    public Usuario obtenerUsuario(String nombreUsuario, String A) {
        String sql = "SELECT * FROM Usuarios WHERE nombreUsuario = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombreUsuario);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Usuario(
                        rs.getString("nombreCompleto"),
                        rs.getString("nombreUsuario"),
                        rs.getInt("edad"),
                        rs.getString("sexo"),
                        rs.getDouble("estatura"),
                        rs.getString("contrasena")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}