package model;



import java.util.Date;

public class IMC {
    private int idIMC;
    private double valorIMC;
    private Date fecha;

    public IMC(double valorIMC, Date fecha) {
        this.valorIMC = valorIMC;
        this.fecha = fecha;
    }

    // Getters y setters

    public int getIdIMC() {
        return idIMC;
    }

    public void setIdIMC(int idIMC) {
        this.idIMC = idIMC;
    }

    public double getValorIMC() {
        return valorIMC;
    }

    public void setValorIMC(double valorIMC) {
        this.valorIMC = valorIMC;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
}