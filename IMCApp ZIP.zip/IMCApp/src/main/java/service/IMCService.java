package service;
import dao.IMCDAO;
import model.Usuario;

import java.util.Date;
import java.util.List;

import model.IMC;



public class IMCService {
    private IMCDAO imcDAO = new IMCDAO();

    public double calcularIMC(double peso, double estatura) {
        return peso / (estatura * estatura);
    }

    public void guardarIMC(Usuario usuario, double valorIMC) {
        IMC imc = new IMC(valorIMC, new Date());
        imcDAO.insertarIMC(usuario, imc);
    }

    public List<IMC> obtenerHistorialIMC(Usuario usuario) {
        return imcDAO.obtenerHistorialIMC(usuario);
    }
}
