package service;

import dao.UsuarioDAO;
import model.Usuario;

public class UsuarioService {
    private UsuarioDAO usuarioDAO = new UsuarioDAO();

    public void registrarUsuario(Usuario usuario) {
        usuarioDAO.insertarUsuario(usuario);
    }

    public Usuario obtenerUsuario(String nombreUsuario) {
        return usuarioDAO.obtenerUsuario(nombreUsuario);
    }

    public boolean autenticarUsuario(String nombreUsuario, String contrasena) {
        Usuario usuario = obtenerUsuario(nombreUsuario);
        return usuario != null && usuario.getContrasena().equals(contrasena);
    }
}