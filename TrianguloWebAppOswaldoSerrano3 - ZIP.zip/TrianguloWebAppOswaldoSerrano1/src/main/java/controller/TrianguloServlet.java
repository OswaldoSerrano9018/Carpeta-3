package controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/TrianguloServlet")
public class TrianguloServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String nombreUsuario = (String) session.getAttribute("nombreUsuario");

        if (nombreUsuario == null) {
            nombreUsuario = request.getParameter("nombre");
            session.setAttribute("nombreUsuario", nombreUsuario);
        }

        double base = Double.parseDouble(request.getParameter("base"));
        double altura = Double.parseDouble(request.getParameter("altura"));

        Triangulo triangulo = new Triangulo(base, altura);
        double area = triangulo.calcularArea();
        double perimetro = triangulo.calcularPerimetro();

        // Guardar resultados en cookies
        response.addCookie(new Cookie("base", String.valueOf(base)));
        response.addCookie(new Cookie("altura", String.valueOf(altura)));
        response.addCookie(new Cookie("area", String.valueOf(area)));
        response.addCookie(new Cookie("perimetro", String.valueOf(perimetro)));

        request.setAttribute("base", base);
        request.setAttribute("altura", altura);
        request.setAttribute("area", area);
        request.setAttribute("perimetro", perimetro);

        request.getRequestDispatcher("resultado.jsp").forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
